function setup() {
  createCanvas(500, 500);
}

function draw() {
  background(200);
}function setup() {
  createCanvas(300, 300);
}

function draw() {
  background("#003366");
  fill ("#ADD8E6")
  ellipse(mouseX,mouseY,20,20);
  push();
  translate(width * 1.2, height * 2.2);
  rotate(frameCount / 200.0);
  star(5, 5, 5, 30, 3);
  pop();

  push();
  translate(width * 0.5, height * 0.5);
  rotate(frameCount / 50.0);
  star(0, 0, 80, 100, 40);
  pop();

  push();
  translate(width * 0.8, height * 0.5);
  rotate(frameCount / -100.0);
  star(0, 0, 30, 70, 5);
  pop();
}

function star(x, y, radius1, radius2, npoints) {
  let angle = TWO_PI / npoints;
  let halfAngle = angle / 2.0;
  beginShape();
  for (let a = 0; a < TWO_PI; a += angle) {
    let sx = x + cos(a) * radius2;
    let sy = y + sin(a) * radius2;
    vertex(sx, sy);
    sx = x + cos(a + halfAngle) * radius1;
    sy = y + sin(a + halfAngle) * radius1;
    vertex(sx, sy);
  }
  endShape(CLOSE);
}
